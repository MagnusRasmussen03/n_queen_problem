import java.util.*;
/**
 * The Solver class finds and prints all valid solutions
 * to the N-Queens problem using recursion and backtracking.
 *
 * Each queen is represented by its column index within a row.
 * For example, queens[row] = col means a queen is placed at (row, col).
 *
 * @author Magnus Rasmussen (AU 801265)
 * @version 24-10-2025
 */
public class Solver
{
    private int noOfQueens; //Antallet af dronninger
    private int[] queens; //Position af dronning i angivne række
    private int noOfSolutions; //Antallet af løsninger
    private boolean showSolutions; // Styrer om løsningerne udskrives på terminalen 

    public static void testSolver(){
        /**
         * Test method for the Solver class. 
         * 
         * This method performs two tests:
         * 1. Finds and prints all solutions for boards of size 1, 2, and 6.
         * 2. Finds and prints the number of solutions for board sizes
         * from 1 to 12 (inclusive), along with speed information.
         */
        Solver s = new Solver(); //Laver en Solver-klasse
        s.findAllSolutions(1); //Finder og printer løsning til bræt størrelse 1.
        s.findAllSolutions(2); //Finder og printer løsning til bræt størrelse 2.
        s.findAllSolutions(6); //Finder og printer løsning til bræt størrelse 6.

        s.findNoOfSolutions(1,12); //Finder og printer løsninger til bræt størrelse 1-12
    }

    public void findAllSolutions(int noOfQueens){
        /**
         * Finds all possible solutions for a board of the given size.
         *
         * @param noOfQueens the number of queens (and size of the board)
         */
        this.noOfQueens=noOfQueens;
        this.queens= new int[noOfQueens];
        this.noOfSolutions = 0;
        this.showSolutions=true;

        System.out.println("**************************");
        System.out.println("Solutions for "+noOfQueens+" queens:");
        System.out.println();

        long start = System.currentTimeMillis(); //Start tid
        positionQueens(0); //Skal starte i 0 (første række), før koden kører korrekt
        long end = System.currentTimeMillis(); //Slut tid
        long timems = end-start; //Endelige tid

        System.out.println();
        System.out.println("A total of " + noOfSolutions + " solutions were found in "+timems+" ms");
        System.out.println("**************************");
    }

    public void findNoOfSolutions(int min, int max){
        /**
         * Finds and prints the number of solutions for the N-queen problem, 
         * for all board sizes from {@param min} to {@param max} both inclusive,
         * and gives the time, it takes to find the solutions, as well as 
         * the time per solution (in milliseconds).
         * 
         * @param min the minimum number of queens (inclusive)
         * @param max the maximum number of queens (inclusive)
         */
        System.out.println("****************************************");
        System.out.format("%-7s %-10s %-8s %-12s%n", "Queens", "Solutions", "Time(ms)", "Solutions/ms");

        for(int n = min; n <= max; n++){
            this.noOfQueens = n;
            this.queens = new int[n];
            this.noOfSolutions = 0;
            this.showSolutions = false;

            long start = System.currentTimeMillis();
            positionQueens(0);
            long end = System.currentTimeMillis();
            long timems = end - start;

            double solPerMs = timems > 0 ? (double) noOfSolutions / timems : noOfSolutions; //Hvis tiden er over 0 ms, finder den tid pr. solution - ellers printer den blot noOfSolutions.

            System.out.format("%-7d %, -10d %-8d %-12.0f%n", n, noOfSolutions, timems, solPerMs);
        }
    }

    private void positionQueens(int row){
        /** This method positions a queen, at a legal position starting at "row"
         *  and increasing with 1, until theres noOfQueens queens on the board.
         *  
         *  @param row the current row where a queen is to be placed
         */
        if(row==noOfQueens){
            if(showSolutions){
                printSolution(); //Hvis showSolutions == true, printes placeringerne af dronningerne.
            }
            noOfSolutions++;
            return; //Hvis rækken når noOfQueens, stopper løkken, da brættet nu er fyldt
        }
        for(int col = 0; col<noOfQueens;col++){
            if(legal(row, col)==true){
                queens[row]=col; //Placer dronning på pladsen
                positionQueens(row+1); //Kalder rekursivt og øger "row" med 1
            }
        }
    }

    private boolean legal(int row, int col){
        /** This method delcares whether or not, it is legal for a queen to be
         *  placed at the given location.
         *  
         * @param row the row index of the attempted placement
         * @param col the column index of the attempted placement
         * @return true if the position is legal, else false.
         */
        for(int i =0;i<row;i++){
            int c = queens[i];
            if(c == col || c == col - (row - i) || c == col + (row - i)){
                return false; //Lodret eller diagonal konflikt
            }
        }
        return true; //Hvis der ikke er en dronning på nogle af disse pladser, er pladsen ledig
    }

    private void printSolution(){
        /**
         * Prints where on the board the noOfQueens queens at positioned
         */
        if(!showSolutions){
            return; //Hvis showSolutions er false, retunerer den bare uden at køre koden.
        }
        for(int i = 0; i<noOfQueens;i++){
            System.out.print(convert(i,queens[i])+" "); //Printer placeringerne af dronningerne.
        }
        System.out.println();
    }

    private String convert(int row, int col){
        /** 
         * Converts "col" from integer to character (col<=26)
         * 
         * @param row the row index
         * @param col the column index
         * @return the converted position as a string (e.g., "a1")
         */

        return "" + (char)('a' + col) + (row+1);//Ændrer kolonneværdier fra int -> char 
                                                //Bytter om på (row,col)->(col,row), så de står korrekt 
                                                //Samt udskriver dem
    }
}